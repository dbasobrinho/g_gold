----------------------------------------------------------------------
purgeLogs: Archive & Cleanup traces, logs in one command (OL9)
Patch 36580169 - PLACEHOLDER FOR purgelogs (Version: 20250707 - Revision: 2.0.1-18)
(OL9 RPM sha256sum: 1813082687cb82367ddb242cbad7ff32fc5e5ece946ea69cb0b4fdbc0368d200)
 
The user documentation is located at MOS: 'purgeLogs: Archive & Cleanup traces, logs in one command (Doc ID 2081655.1)'
--> https://support.oracle.com/epmos/faces/DocumentDisplay?id=2081655.1

The patch consists of one zip file within an RPM.
----------------------------------------------------------------------
