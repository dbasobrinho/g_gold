----------------------------------------------------------------------
purgeLogs: Archive & Cleanup traces, logs in one command (OL7)
Patch 36518442 - PLACEHOLDER FOR purgelogs (Version: 20250707 - Revision: 2.0.1-18)
(OL7 RPM sha256sum: 76ce964a0a1c1c8d7a9f2bce1b5de03b68c3a3c6457fedfcf4efeaadb6825658)
 
The user documentation is located at MOS: 'purgeLogs: Archive & Cleanup traces, logs in one command (Doc ID 2081655.1)'
--> https://support.oracle.com/epmos/faces/DocumentDisplay?id=2081655.1

The patch consists of one zip file within an RPM.
----------------------------------------------------------------------
