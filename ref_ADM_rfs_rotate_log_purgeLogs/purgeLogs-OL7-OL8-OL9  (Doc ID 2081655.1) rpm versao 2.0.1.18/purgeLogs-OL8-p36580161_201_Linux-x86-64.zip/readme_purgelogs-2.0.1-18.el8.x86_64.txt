----------------------------------------------------------------------
purgeLogs: Archive & Cleanup traces, logs in one command (OL8)
Patch 36580161 - PLACEHOLDER FOR purgelogs (Version: 20250707 - Revision: 2.0.1-18)
(OL8 RPM sha256sum: 6fe7320a767d25bfe1c8aadcd5ab527dd5cf7b2b07c6a26ad966f78884484a6c)
 
The user documentation is located at MOS: 'purgeLogs: Archive & Cleanup traces, logs in one command (Doc ID 2081655.1)'
--> https://support.oracle.com/epmos/faces/DocumentDisplay?id=2081655.1

The patch consists of one zip file within an RPM.
----------------------------------------------------------------------
