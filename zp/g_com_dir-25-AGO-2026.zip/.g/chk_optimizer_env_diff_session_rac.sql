SET COLSEP '|'
SET LINES 250
SET PAGES 200

COLUMN inst_id        FORMAT 999 HEADING 'INS'
COLUMN sid            FORMAT 99999
COLUMN serial#        FORMAT 99999
COLUMN username       FORMAT A33
COLUMN service_name   FORMAT A60
COLUMN name           FORMAT A35
COLUMN default_value  FORMAT A15
COLUMN session_value  FORMAT A15

SELECT s.inst_id,
       s.sid,
       s.serial#,
       s.username,
       s.service_name,
       dp.name,
       dp.value AS default_value,
       sp.value AS session_value
FROM   gv$session s
JOIN   gv$ses_optimizer_env sp
       ON sp.sid = s.sid
      AND sp.inst_id = s.inst_id
JOIN   gv$sys_optimizer_env dp
       ON dp.id = sp.id
      AND dp.inst_id = sp.inst_id
WHERE  s.username IS NOT NULL
AND    sp.value <> dp.value
AND    dp.name NOT IN ('active_instance_count', 'total_processor_group_count')
and s.service_name not in ('SYS$BACKGROUND')	
--AND    s.username IN ('GCP_CONMATER','BASKET_ONLINE','GCP_CONSUMER_PBAS')
ORDER BY s.username,          s.service_name,          s.inst_id,          s.sid,          dp.name;