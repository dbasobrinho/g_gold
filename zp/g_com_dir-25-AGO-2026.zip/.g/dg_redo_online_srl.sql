-- |
-- +-------------------------------------------------------------------------------------------+
-- | Objetivo   : Exibir ONLINE REDO LOGS e STANDBY REDO LOGS por THREAD                       |
-- | Criador    : Roberto Fernandes Sobrinho                                                   |
-- | Data       : 04/10/2025                                                                   |
-- | Exemplo    : @dg_redo_online_srl.sql                                                      |
-- | Arquivo    : dg_redo_online_srl.sql                                                       |
-- | Referência : https://dbasobrinho.com.br                                                   |
-- | Modificação: 1.0 - DBASobrinho - Versão inicial                                           |
-- +-------------------------------------------------------------------------------------------+
-- |                                                                https://dbasobrinho.com.br |
-- +-------------------------------------------------------------------------------------------+
-- |Peppa Pig diz: "Eu adoro pular em poças de Lama"                                           |
-- +-------------------------------------------------------------------------------------------+

SET TERMOUT OFF;
ALTER SESSION SET NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS';
EXEC dbms_application_info.set_module(module_name => 'd[dg_redo_online_srl.sql]', action_name => 'd[dg_redo_online_srl.sql]');
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance FROM dual;
SET TERMOUT ON;

PROMPT
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Script   : ONLINE x STANDBY REDO por THREAD                      +-+-+-+-+-+-+-+-+-+-+-+  |
PROMPT | Instancia: &current_instance                                     |d|b|a|s|o|b|r|i|n|h|o|  |
PROMPT | Versao   : 1.0                                                   +-+-+-+-+-+-+-+-+-+-+-+  |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT .

SET ECHO        OFF
SET FEEDBACK    10
SET HEADING     ON
SET LINES       188
SET PAGES       300
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF
SET COLSEP ' | '
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

-- =====================================================================
-- Mostra quantidade de ONLINE e STANDBY REDO LOGS por THREAD
-- Regra: SRL_NEEDED = ONLINE_GROUPS + 1
-- =====================================================================
COLUMN THREAD#       FORMAT 9999
COLUMN ONLINE_GROUPS FORMAT 9999
COLUMN SRL_GROUPS    FORMAT 9999
COLUMN SRL_NEEDED    FORMAT 9999

SELECT t.thread#,
       online_groups,
       srl_groups,
       (online_groups + 1) AS srl_needed
FROM (
  SELECT thread#,
         SUM(CASE src WHEN 'ONLINE' THEN cnt ELSE 0 END) AS online_groups,
         SUM(CASE src WHEN 'SRL'    THEN cnt ELSE 0 END) AS srl_groups
  FROM (
    SELECT thread#, COUNT(DISTINCT group#) cnt, 'ONLINE' AS src FROM v$log GROUP BY thread#
    UNION ALL
    SELECT NVL(thread#,1), COUNT(DISTINCT group#), 'SRL' FROM v$standby_log GROUP BY thread#
  ) x
  GROUP BY thread#
) t
ORDER BY t.thread#;

