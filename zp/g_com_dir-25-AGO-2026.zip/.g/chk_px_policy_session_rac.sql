SET COLSEP '|'
SET LINES 200
SET PAGES 100

COLUMN inst_id  FORMAT 999 HEADING 'INS'
COLUMN sid      FORMAT 99999
COLUMN serial#  FORMAT 99999
COLUMN username FORMAT A25
COLUMN parallel_degree_policy FORMAT A10 HEADING 'PX_POLICY'

SELECT s.inst_id,
       s.sid,
       s.serial#,
       s.username,
       oe.value AS parallel_degree_policy
FROM   gv$session s
JOIN   gv$ses_optimizer_env oe
       ON oe.sid = s.sid
      AND oe.inst_id = s.inst_id
WHERE  s.username is not null
--and     s.username IN ('GCP_CONMATER','BASKET_ONLINE','GCP_CONSUMER_PBAS')
AND    oe.name = 'parallel_degree_policy'
ORDER BY s.username, s.inst_id, s.sid;