
-- ###########################################################################
-- Script   : ash_trans_xid_history.sql
-- Objetivo : Exibir o historico ASH de uma transacao Oracle a partir do XID
-- Uso      : @ash_trans_xid_history.sql 01A3000E000F1AF8
-- Exemplo  : @ash_trans_xid_history.sql 01A3000E000F1AF8
-- ###########################################################################

SET COLSEP '|'
SET TAB         OFF
SET ECHO        OFF
SET FEEDBACK    ON
SET HEADING     ON
SET LINES      290
SET PAGES       400
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN XID_HEX NEW_VALUE V_XID NOPRINT

COLUMN sample_time      FORMAT A16 HEADING 'TIME'
COLUMN inst_id          FORMAT 99  HEADING 'I'
COLUMN sid_serial       FORMAT A14 HEADING 'SID,SER,@I'
COLUMN username         FORMAT A12 HEADING 'USER'
COLUMN session_type     FORMAT A4  HEADING 'TYPE'
COLUMN session_state    FORMAT A6  HEADING 'STATE'
COLUMN event            FORMAT A28 HEADING 'EVENT'
COLUMN wait_class       FORMAT A10 HEADING 'WAIT'
COLUMN sql_id           FORMAT A13 HEADING 'SQL_ID'
COLUMN top_level_sql_id FORMAT A13 HEADING 'TOP_SQL_ID'
COLUMN sql_opname       FORMAT A6  HEADING 'OP'
COLUMN blocking_sess    FORMAT A10 HEADING 'BLOCK'
COLUMN program          FORMAT A18 HEADING 'PROGRAM'
COLUMN module           FORMAT A18 HEADING 'MODULE'
COLUMN machine          FORMAT A14 HEADING 'MACHINE'
COLUMN obj_info         FORMAT A24 HEADING 'OBJECT'
COLUMN xid              FORMAT A16 HEADING 'XID'
COLUMN p1text           FORMAT A8  HEADING 'P1TEXT'
COLUMN p2text           FORMAT A8  HEADING 'P2TEXT'
COLUMN p3text           FORMAT A8  HEADING 'P3TEXT'

SELECT UPPER('&1') AS XID_HEX FROM dual;

PROMPT
PROMPT ==========================================================================
PROMPT Historico ASH da transacao XID = &V_XID
PROMPT ==========================================================================

SELECT
    TO_CHAR(ash.sample_time,'DD/MM HH24:MI:SS')                  AS sample_time,
    ash.inst_id                                                  AS inst_id,
    ash.session_id || ',' || ash.session_serial# || ',@' ||
    ash.inst_id                                                  AS sid_serial,
    NVL(u.username,'-')                                          AS username,
    substr(ash.session_type,1,4)                                 AS session_type,
    substr(ash.session_state,1,6)                                AS session_state,
    SUBSTR(NVL(ash.event,'-'),1,28)                              AS event,
    SUBSTR(NVL(ash.wait_class,'-'),1,10)                         AS wait_class,
    NVL(ash.sql_id,'-')                                          AS sql_id,
    NVL(ash.top_level_sql_id,'-')                                AS top_level_sql_id,
    SUBSTR(NVL(ash.sql_opname,'-'),1,6)                          AS sql_opname,
    NVL(TO_CHAR(ash.blocking_session) || ',@' ||
        TO_CHAR(ash.blocking_inst_id), '-')                      AS blocking_sess,
    --SUBSTR(NVL(ash.program,'-'),1,18)                            AS program,
    --SUBSTR(NVL(ash.module,'-'),1,18)                             AS module,
    SUBSTR(NVL(ash.machine,'-'),1,14)                            AS machine,
    CASE
        WHEN o.owner IS NOT NULL
        THEN SUBSTR(o.owner || '.' || o.object_name,1,24)
        ELSE '-'
    END                                                          AS obj_info,
    --RAWTOHEX(ash.xid)                                            AS xid,
    SUBSTR(NVL(ash.p1text,'-'),1,8)                              AS p1text,
    SUBSTR(NVL(ash.p2text,'-'),1,8)                              AS p2text,
    SUBSTR(NVL(ash.p3text,'-'),1,8)                              AS p3text
FROM gv$active_session_history ash
LEFT JOIN dba_users u
       ON u.user_id = ash.user_id
LEFT JOIN dba_objects o
       ON o.object_id = ash.current_obj#
WHERE RAWTOHEX(ash.xid) = '&V_XID'
ORDER BY ash.sample_time, ash.inst_id, ash.session_id;

PROMPT
PROMPT ==========================================================================
PROMPT Resumo dos SQL_IDs encontrados para o XID &V_XID
PROMPT ==========================================================================

COLUMN samples    FORMAT 999999 HEADING 'SAMPLES'
COLUMN first_seen FORMAT A16    HEADING 'FIRST_SEEN'
COLUMN last_seen  FORMAT A16    HEADING 'LAST_SEEN'

SELECT
    NVL(sql_id,'-')                                  AS sql_id,
    COUNT(*)                                         AS samples,
    TO_CHAR(MIN(sample_time),'DD/MM HH24:MI:SS')     AS first_seen,
    TO_CHAR(MAX(sample_time),'DD/MM HH24:MI:SS')     AS last_seen
FROM gv$active_session_history
WHERE RAWTOHEX(xid) = '&V_XID'
GROUP BY sql_id
ORDER BY samples DESC, sql_id;

PROMPT
PROMPT ==========================================================================
PROMPT Resumo dos objetos encontrados para o XID &V_XID
PROMPT ==========================================================================

COLUMN object_samples FORMAT 999999 HEADING 'SAMPLES'
COLUMN owner          FORMAT A15    HEADING 'OWNER'
COLUMN object_name    FORMAT A30    HEADING 'OBJECT_NAME'
COLUMN object_type    FORMAT A18    HEADING 'OBJECT_TYPE'

SELECT
    o.owner,
    o.object_name,
    o.object_type,
    COUNT(*) AS object_samples
FROM gv$active_session_history ash
JOIN dba_objects o
  ON o.object_id = ash.current_obj#
WHERE RAWTOHEX(ash.xid) = '&V_XID'
GROUP BY o.owner, o.object_name, o.object_type
ORDER BY object_samples DESC, o.owner, o.object_name;

