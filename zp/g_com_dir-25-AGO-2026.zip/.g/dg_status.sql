-- |
-- +-------------------------------------------------------------------------------------------+
-- | Objetivo   : GAP Replicacao Data Guard (RAC-ready)                                        |
-- | Criador    : Roberto Fernandes Sobrinho                                                   |
-- | Data       : 02/10/2025                                                                   |
-- | Exemplo    : @dg_status.sql                                                             |
-- | Arquivo    : dg_status.sql                                                                |
-- | Referencia :                                                                              |
-- | Modificacao: 1.4 - execucao por relatorio (primario/standby), padrao de prompts           |
-- +-------------------------------------------------------------------------------------------+
-- |                                                                https://dbasobrinho.com.br |
-- +-------------------------------------------------------------------------------------------+
-- |Peppa Pig diz: "Eu adoro pular em pocas de Lama"                                           |
-- +-------------------------------------------------------------------------------------------+

-- base de sessao
SET FEEDBACK    off
SET HEADING     ON
SET LINES       190
SET PAGES       300
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF
SET COLSEP      '|'
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

SET TERMOUT OFF;
ALTER SESSION SET NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS';
EXEC dbms_application_info.set_module(module_name => 'd[dg_status.sql]', action_name => 'd[dg_status.sql]');

COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT RPAD(sys_context('USERENV','INSTANCE_NAME'),17) current_instance FROM dual;

COLUMN DG_CONF NEW_VALUE DG_CONF NOPRINT;
SELECT value DG_CONF FROM v$parameter WHERE name='log_archive_config';

col dt1 noprint new_value dt1
SELECT   'dg_status_'||TO_CHAR (SYSDATE, 'yyyymmddhh24miss') || '.log' dt1 FROM DUAL;
spool &&dt1
SET TERMOUT ON;
PROMPT
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | https://github.com/dbasobrinho/g_gold/blob/main/dg_status.sql                             |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Script   : DG Monitor Geral                                      +-+-+-+-+-+-+-+-+-+-+-+  |
PROMPT | Instancia: &current_instance                                     |d|b|a|s|o|b|r|i|n|h|o|  |
PROMPT | Versao   : 1.4                                                   +-+-+-+-+-+-+-+-+-+-+-+  |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | DG_CONF  : &DG_CONF                                                                    
PROMPT +-------------------------------------------------------------------------------------------+               
PROMPT | Use ENTER para assumir o default                                                          |
PROMPT +-------------------------------------------------------------------------------------------+
ACCEPT DIAS NUMBER DEFAULT 5 PROMPT 'dias (default 5): '
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | DIAS escolhido: &&DIAS                                                                  
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..
PROMPT .
/* =================================================================================================
   Relatorio 1
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 1) Infos basicas: papel do banco e gap por thread                               |
PROMPT | Mostra se o banco esta em modo PRIMARY ou STANDBY, o nivel de protecao configurado e      |
PROMPT | compara o ultimo archived log recebido com o ultimo aplicado em cada thread.              |
PROMPT | O campo MINUTOS indica o atraso temporal em minutos, enquanto ARC_DIFF mostra a           |
PROMPT | quantidade de arquivos de redo ainda nao aplicados.                                       |
PROMPT | Execucao: PRIMARIO e STANDBY                                                              |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

COLUMN REPLICACAO_DG          FORMAT a100       HEAD 'REPLICACAO DG CONFIGURACAO' justify CENTER
COLUMN STANDBY_LAST_RECEIVED  FORMAT 9999999    HEAD 'ULTIMO ARC|ORIGEM'          justify CENTER
COLUMN STANDBY_LAST_APPLIED   FORMAT 9999999    HEAD 'ULTIMO ARC|DESTINO'         justify CENTER
COLUMN STANDBY_DT_LAST_APP    FORMAT a19        HEAD 'ULTIMA DATA|DESTINO'        justify CENTER
COLUMN data_atual             FORMAT a19        HEAD 'DATA| ATUAL'                justify CENTER
COLUMN MINUTOS                FORMAT 999999     HEAD 'DIF|MIN'                    justify CENTER
COLUMN ARC_DIFF               FORMAT 999999     HEAD 'DIF|ARC'                    justify CENTER
COLUMN DATABASE_ROLE          FORMAT a16        HEAD 'DATABASE|PERFIL'            justify CENTER
COLUMN PROTECTION_MODE        FORMAT a20        HEAD 'MODO|PROTECAO'              justify CENTER
COLUMN thread                 FORMAT 99999      HEAD 'THREAD|'                    justify CENTER
COLUMN SWITCHOVER_STATUS      FORMAT a16        HEAD 'SWITCHOVER|STATUS'          justify CENTER
COLUMN DEST_ID                FORMAT 999        HEAD 'ID|DEST'                    justify CENTER
COLUMN NAME                   FORMAT a10        HEAD 'DEST|NAME'                  justify CENTER
COLUMN ST                     FORMAT a03        HEAD 'ST|'                        justify CENTER
COLUMN NAME                   FORMAT a20        HEAD 'NAME|DESTINATION'           justify CENTER

PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Status FUZZY Datafiles                                                                    |
PROMPT +-------------------------------------------------------------------------------------------+
COLUMN STATUS                FORMAT a10        HEAD 'STATUS'             JUSTIFY CENTER
COLUMN FUZZY                 FORMAT a08        HEAD 'FUZZY'              JUSTIFY CENTER
COLUMN CHECKPOINT_CHANGE     FORMAT a25        HEAD 'CHECKPOINT CHANGE'  JUSTIFY CENTER 
COLUMN CHECKPOINT_TIME       FORMAT a25        HEAD 'CHECKPOINT TIME'    JUSTIFY CENTER 
COLUMN CNT                   FORMAT 9999999    HEAD 'TOTAL'              JUSTIFY CENTER 
SELECT status,
       TO_CHAR(checkpoint_change#) checkpoint_change,
       TO_CHAR(checkpoint_time,'dd-mon-yyyy hh24:mi:ss') checkpoint_time,
       COUNT(*) cnt,
       fuzzy
  FROM v$datafile_header
 GROUP BY status, checkpoint_change#, checkpoint_time, fuzzy
 ORDER BY status, checkpoint_change#, checkpoint_time
/

PROMPT .
PROMPT .
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Data Guard GAP Status                                                                     |
PROMPT +-------------------------------------------------------------------------------------------+
SET FEEDBACK OFF
SELECT CASE WHEN ARC_DIFF <= 3 THEN ':)'
            WHEN ARC_DIFF > 3 AND ARC_DIFF <= 8 THEN ':|'
            ELSE ':(' END AS ST,
       z.DATABASE_ROLE, z.PROTECTION_MODE, z.SWITCHOVER_STATUS, z.name, z.thread,
       z.STANDBY_LAST_RECEIVED, z.STANDBY_LAST_APPLIED, z.STANDBY_DT_LAST_APP,
       z.MINUTOS, z.ARC_DIFF
FROM (
  SELECT c.DATABASE_ROLE,
         c.PROTECTION_MODE,
         c.SWITCHOVER_STATUS,
         a.DEST_ID,
         (SELECT MAX(NVL2(xx.name, xx.DEST_ID||' - '||xx.name, NULL))
            FROM v$archived_log xx
           WHERE xx.DEST_ID = a.DEST_ID
             AND xx.resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
             AND sequence# = (SELECT MAX(yy.sequence#)
                                FROM v$archived_log yy
                               WHERE yy.resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
                                 AND yy.DEST_ID = xx.DEST_ID)
         ) AS name,
         a.thread# thread,
         b.last_seq STANDBY_LAST_RECEIVED,
         a.applied_seq STANDBY_LAST_APPLIED,
         TO_CHAR(a.last_app_timestamp,'DD/MM/YYYY HH24:MI:SS') AS STANDBY_DT_LAST_APP,
         TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS') AS DATA_ATUAL,
         (SYSDATE - a.last_app_timestamp)*24*60 AS MINUTOS,
         b.last_seq - a.applied_seq AS ARC_DIFF
  FROM   (SELECT /*+ PARALLEL(8) */
                 DEST_ID, thread#,
                 MAX(sequence#) applied_seq,
                 MAX(next_time) last_app_timestamp
          FROM   gv$archived_log
          WHERE  applied = 'YES'
            AND  resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
          GROUP  BY DEST_ID, thread#) a
  JOIN   (SELECT /*+ PARALLEL(8) */
                 DEST_ID, thread#,
                 MAX(sequence#) last_seq
          FROM   gv$archived_log
          WHERE  resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
          GROUP  BY DEST_ID, thread#) b
    ON   a.thread# = b.thread#
   AND   a.DEST_ID = b.DEST_ID
  CROSS JOIN (SELECT DATABASE_ROLE, DB_UNIQUE_NAME INSTANCE, OPEN_MODE,
                     PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS
              FROM   V$DATABASE) c
) z
WHERE UPPER(z.NAME) NOT LIKE '%ARCHIVELOG%'
  AND ( (z.DATABASE_ROLE = 'PRIMARY' AND (z.thread, z.DEST_ID) IN
          (SELECT INST_ID, DEST_ID FROM GV$ARCHIVE_DEST_STATUS WHERE STATUS <> 'INACTIVE'))
        OR (z.DATABASE_ROLE <> 'PRIMARY') )
ORDER BY z.name, z.thread
/
SET FEEDBACK off

/* =================================================================================================
   Relatorio 2
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 2) Mensagens e erros do Data Guard (ultimos &&DIAS dias)                        |
PROMPT | Lista eventos do DG por instancia e destino, com severidade, codigo de erro e timestamp.  |
PROMPT | Indica falhas de envio/recepcao, destinos problematicos e repeticoes de erro.             |
PROMPT | Campos chave: INSTANCE_NAME, SEVERITY, DEST_ID, MESSAGE_NUM, ERROR_CODE, TIMESTAMP, MSG.  |
PROMPT | Execucao: PRIMARIO e STANDBY                                                              |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SET HEADING ON
SET LINES       190
SET PAGES       300
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN INSTANCE_NAME  FORMAT a12
COLUMN FACILITY       FORMAT a13
COLUMN SEVERITY       FORMAT a08
COLUMN DEST_ID        FORMAT 99        HEAD 'DEST'       JUSTIFY CENTER
COLUMN MESSAGE_NUM    FORMAT 999999    HEAD 'MSG|NUM'    JUSTIFY CENTER
COLUMN ERROR_CODE     FORMAT 999999    HEAD 'ERROR|COD'  JUSTIFY CENTER
COLUMN CALLOUT        FORMAT a4        HEAD 'CALL|OUT'  JUSTIFY CENTER
COLUMN MESSAGE        FORMAT a100

SELECT i.instance_name,
       SUBSTR(d.facility,1,13) AS facility,
       SUBSTR(d.severity,1,7)  AS severity,
       d.dest_id,
       d.message_num,
       d.error_code,
       d.callout,
       d.timestamp,
       substr(' '||d.message,1,100) AS message
FROM   gv$dataguard_status d
JOIN   gv$instance i USING(inst_id)
WHERE  d.timestamp > SYSDATE - NVL(TO_NUMBER('&&DIAS'),7)
ORDER  BY d.message_num DESC
/

/* =================================================================================================
   Relatorio 3
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 3) Processos do standby                                                         |
PROMPT | Mostra os processos de background do standby, incluindo MRP (apply) e RFS (recepcao),     |
PROMPT | com status, cliente associado, thread e sequencia atual.                                  |
PROMPT | Permite identificar se o apply esta ativo, se ha recepcao de redo e possiveis travamentos |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT i.instance_name, m.pid, m.process, m.status, m.client_process, m.client_pid,
       m.thread#, m.sequence# AS seq#, m.block#, m.blocks
FROM   gv$managed_standby m
JOIN   gv$instance i USING(inst_id)
;

/* =================================================================================================
   Relatorio 4
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 4) Ultimos archived logs recebidos                                              |
PROMPT | Lista os ultimos 50 archived logs registrados no standby, mostrando thread e sequence.    |
PROMPT | Util para verificar a ordem de chegada e possiveis buracos na sequencia de redo.          |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT *
FROM (
  SELECT registrar, creator, thread#, sequence#, first_change#, next_change#
  FROM   gv$archived_log
  ORDER  BY first_change# DESC, next_change# DESC
)
WHERE  ROWNUM < 50
ORDER  BY first_change#, next_change#
;

/* =================================================================================================
   Relatorio 5
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 5) Ultimo log aplicado e ultimo log recebido                                    |
PROMPT | Mostra a data e hora do ultimo archived log aplicado e do ultimo recebido no standby.     |
PROMPT | Permite comparar se ha defasagem entre recepcao e aplicacao dos redos.                    |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT 'Last Log applied : '  AS Logs,
       TO_CHAR(next_time,'DD-MON-YY:HH24:MI:SS') AS Time
FROM   gv$archived_log
WHERE  sequence# = (SELECT MAX(sequence#) FROM gv$archived_log WHERE applied='YES')
UNION
SELECT 'Last Log received : ' AS Logs,
       TO_CHAR(next_time,'DD-MON-YY:HH24:MI:SS') AS Time
FROM   gv$archived_log
WHERE  sequence# = (SELECT MAX(sequence#) FROM gv$archived_log)
;

/* =================================================================================================
   Relatorio 6
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 6) Estatisticas de lag e redo (V$DATAGUARD_STATS)                               |
PROMPT | Exibe metricas de lag de aplicacao e de transporte do Data Guard, com horario de coleta.  |
PROMPT | Util para identificar atraso acumulado entre primary e standby.                           |
PROMPT | Execucao: STANDBY                                                              |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

COLUMN lag_time    FORMAT a17
COLUMN datum_time  FORMAT a28
COLUMN TIME_COMP   FORMAT a28
COLUMN UNIQUE_NAME FORMAT a11
COLUMN NAME        FORMAT a40

SELECT SOURCE_DBID           AS DBID,
       SOURCE_DB_UNIQUE_NAME AS UNIQUE_NAME,
       NAME,
       VALUE                 AS LAG_TIME,
       DATUM_TIME            AS DATUM_TIME,
       TIME_COMPUTED         AS TIME_COMP,
       UNIT
FROM   V$DATAGUARD_STATS
;

/* =================================================================================================
   Relatorio 7
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 7) Progresso do apply (taxas e redo aplicado)                                   |
PROMPT | Mostra a velocidade atual e media do apply, alem do volume de redo ja aplicado.           |
PROMPT | Util para acompanhar eficiencia do processo de aplicacao no standby.                      |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT TO_CHAR(start_time, 'DD-MON-RR HH24:MI:SS') AS start_time,
       item,
       sofar || ' ' || units AS sofar
FROM   v$recovery_progress
WHERE  item IN ('Active Apply Rate','Average Apply Rate','Redo Applied')
;

/* =================================================================================================
   Relatorio 8
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 8) Timestamp do ultimo log aplicado                                             |
PROMPT | Mostra a data e hora em que o ultimo archived log foi efetivamente aplicado no standby.   |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT TO_CHAR(MAX(first_time),'hh24:mi:ss dd/mm/yyyy') AS last_applied_time
FROM   gv$archived_log
WHERE  applied='YES'
;

/* =================================================================================================
   Relatorio 9
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 9) Standby Redo Logs                                                            |
PROMPT | Verifica a existencia, tamanho e status dos standby redo logs em cada thread.             |
PROMPT | Confirma se a quantidade e o tamanho estao adequados em relacao aos online redo logs.     |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT thread#, group#, sequence#, bytes, archived, status
FROM   v$standby_log
ORDER  BY thread#, group#
;

/* =================================================================================================
   Relatorio 10
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 10) Destinos de archive (enable/status/process/mountid)                         |
PROMPT | Lista os ARCHIVE_DEST_n configurados, mostrando se estao ativos, o processo associado e   |
PROMPT | possiveis erros. Indica se o destino e local ou remoto e o mountid correspondente.        |
PROMPT | Execucao: PRIMARIO e STANDBY                                                              |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

COLUMN destination FORMAT a35 WRAP
COLUMN process     FORMAT a7
COLUMN id          FORMAT 99
COLUMN mid         FORMAT 99
COLUMN error       FORMAT a50

SELECT NVL(t.thread#, 0)       AS thread_no,
       gvi.instance_name,
       gvad.dest_id,
       gvad.destination,
       gvad.status,
       SUBSTR(gvad.error,1,50) AS error,
       gvad.target,
       gvad.schedule,
       gvad.process,
       gvad.mountid            AS mid
FROM   gv$archive_dest gvad
JOIN   gv$instance     gvi USING (inst_id)
LEFT   JOIN gv$thread  t   USING (inst_id)   -- usando USING aqui tambem
WHERE  gvad.destination IS NOT NULL
ORDER  BY NVL(t.thread#,0), gvad.dest_id;


/* =================================================================================================
   Relatorio 11
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 11) Ultima sequence recebida x aplicada (por thread)                            |
PROMPT | Compara a ultima sequence recebida com a ultima aplicada em cada thread.                  |
PROMPT | Util para identificar rapidamente qual thread esta com atraso na aplicacao.               |
PROMPT | Execucao: STANDBY                                                                         |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SELECT al.thrd AS "Thread",
       almax   AS "Last Seq Received",
       lhmax   AS "Last Seq Applied"
FROM  (SELECT thread# thrd, MAX(sequence#) almax
       FROM   gv$archived_log
       WHERE  resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
       GROUP  BY thread#) al
JOIN  (SELECT thread# thrd, MAX(sequence#) lhmax
       FROM   gv$log_history
       WHERE  resetlogs_change#=(SELECT resetlogs_change# FROM v$database)
       GROUP  BY thread#) lh
ON    al.thrd = lh.thrd
;

/* =================================================================================================
   Relatorio 12
================================================================================================= */
PROMPT ..
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio 12) Ultimo archived log por thread                                             |
PROMPT | Lista por thread a ultima sequence arquivada, com horarios FIRST_TIME e NEXT_TIME.       |
PROMPT | Execucao: PRIMARIO e STANDBY                                                              |
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT ..

SET FEEDBACK OFF

COLUMN THREAD      FORMAT 99999     HEAD 'THREAD'
COLUMN LAST_SEQ    FORMAT 9999999   HEAD 'ULTIMO|SEQ'
COLUMN FIRST_TIME  FORMAT a19       HEAD 'FIRST|TIME'
COLUMN NEXT_TIME   FORMAT a19       HEAD 'NEXT|TIME'

SELECT t.thread#                                    AS thread,
       t.last_seq                                   AS last_seq,
       TO_CHAR(a.first_time,'DD/MM/YYYY HH24:MI:SS') AS first_time,
       TO_CHAR(a.next_time ,'DD/MM/YYYY HH24:MI:SS') AS next_time
FROM (
  SELECT thread#, MAX(sequence#) AS last_seq
  FROM   gv$archived_log
  WHERE  resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
  GROUP  BY thread#
) t
JOIN (
  -- agrega por thread+sequence para evitar linhas duplicadas por DEST_ID
  SELECT thread#, sequence#,
         MAX(first_time) AS first_time,
         MAX(next_time)  AS next_time
  FROM   gv$archived_log
  WHERE  resetlogs_change# = (SELECT resetlogs_change# FROM v$database)
  GROUP  BY thread#, sequence#
) a
  ON a.thread#   = t.thread#
 AND a.sequence# = t.last_seq
ORDER BY t.thread#
/

SET FEEDBACK ON

/* =================================================================================================
   Rodape
================================================================================================= */
SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT RPAD(sys_context('USERENV','INSTANCE_NAME'),17) current_instance FROM dual;
SET TERMOUT ON;

PROMPT 
PROMPT +-------------------------------------------------------------------------------------------+
PROMPT | Relatorio : DG Status Replicacao                                                          |
PROMPT | Instance  : &current_instance                                                             |
PROMPT +-------------------------------------------------------------------------------------------+

SPOOL OFF
PROMPT .
PROMPT Relatorio salvo em &&dt1
PROMPT .
set feedback on 
UNDEFINE DIAS
