EXEC SYS.utl_recomp.recomp_parallel(8)
/