rem
rem Displays all statistics information for owner/table
rem
 
@stat-x-main
@stat-x-tab-body
@stat-x-part-body
@stat-x-col-body
--@stat-x-col-virtual-body
@stat-x-histat-x-body
@stat-x-idx-body
@stat-x-idx-part-body
