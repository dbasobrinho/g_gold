--
COLUMN CON_ID      FORMAT  9999  
COLUMN CON_NAME    FORMAT  A40  
show con_id con_name user;
