@tbs_temp_default.sql
@tbs_free_temp.sql
@tbs_temp_file.sql
@tbs_temp_used_by_full.sql