ps -ef |grep -i local=no
