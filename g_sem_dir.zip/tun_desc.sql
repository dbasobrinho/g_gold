-- Lista colunas de uma tabela
-- --------------------------------------------------------------------
set lines 70 pages 0 
desc &1
set lines 200 pages 80  