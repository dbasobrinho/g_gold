@advice_sga.sql 
prompt . . .
prompt <enter>
PAUSE
@advice_pga.sql
prompt . . .
prompt <enter>
PAUSE
@advice_db_cache.sql
prompt . . .
prompt <enter>
PAUSE
@advice_shared_pool.sql
prompt . . .