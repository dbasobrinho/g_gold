#!/bin/bash
find $ORACLE_BASE -type f -name alert_$ORACLE_SID.log