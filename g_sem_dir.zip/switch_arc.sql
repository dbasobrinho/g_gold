set echo on;
ALTER SYSTEM ARCHIVE LOG CURRENT ;
set echo off;
