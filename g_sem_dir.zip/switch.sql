set echo on;
ALTER SYSTEM SWITCH LOGFILE;
set echo off;
