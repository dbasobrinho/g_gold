export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
$ORACLE_HOME/oratop.RDBMS_11.2_LINUX_X64 -f -i 1 / as sysdba