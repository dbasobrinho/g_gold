ps -ef |grep -i local=no |wc -l
