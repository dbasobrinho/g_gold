##Comando para verificar arquivos e diretorios vazios, substituir o /path/to/dest pelo caminho que deseja. 
## f = file ; d = directory 
find  /path/to/dest -type f -empty
find  /path/to/dest -type d -empty




 

