
set lines 1000
set pages 1000
select * from hmuser.vw_monitor_placas;
