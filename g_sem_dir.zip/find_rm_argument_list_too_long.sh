#!/bin/bash
find /G/to/folder -name "filenamestart*" -type f -exec rm -f {} \;