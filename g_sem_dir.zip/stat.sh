#!/bin/bash
##while true;do tail -100 /bkp_full_pback_crise/full/logs/restore_ppback_hell.log; sleep 60; tail -100 /u/app/oracle/diag/rdbms/pback/pback/trace/alert_pback.log;sleep 60;sql @/tmp/scr/stat.sql;/tmp/scr/stat.sh;sleep 60;done	
export ORACLE_SID=pback
echo . 
echo . .
echo . . .
echo ================================================================
echo O GUINA NAO TINHA DÓ, SE REAGIR BUM VIRA PÓ!!!!!!!
echo ================================================================
echo . . .
echo . .
echo .
