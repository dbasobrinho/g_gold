set lines 1000
set pages 1000
@$ORACLE_HOME/rdbms/admin/ashrpt.sql